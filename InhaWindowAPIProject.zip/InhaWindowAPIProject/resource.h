﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++에서 생성한 포함 파일입니다.
// InhaWindowAPIProject.rc에서 사용되고 있습니다.
//
#define IDC_MYICON                      2
#define IDOK2                           3
#define IDCANCEL2                       3
#define IDOK3                           4
#define IDD_MODELESS                    9
#define IDD_INHAWINDOWAPIPROJECT_DIALOG 102
#define IDS_APP_TITLE                   103
#define IDD_ABOUTBOX                    103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDI_INHAWINDOWAPIPROJECT        107
#define IDI_SMALL                       108
#define IDC_INHAWINDOWAPIPROJECT        109
#define IDR_MAINFRAME                   128
#define IDB_BITMAP1                     132
#define IDD_DIALOG1                     133
#define IDD_DIALOG                      133
#define IDD_DIALOG2                     134 
#define IDD_MODURLESS                   135
#define IDC_BUTTON1                     1006
#define IDC_BTN_CLOSE                   1006
#define IDC_BTN_LIST_INSERT             1006
#define IDC_BTN_START                   1007
#define IDC_BTN_PAUSE                   1008
#define IDC_BTN_INFO                    1009
#define IDC_EDIT_SOURCE                 1010
#define IDC_EDIT_DEST                   1011
#define IDC_BTN_CLEAR                   1012
#define IDC_BTN_COPY                    1013
#define IDC_BTN_EXIT                    1014
#define IDC_CHECK_READING               1015
#define IDC_CHECK_MUSIC                 1016
#define IDC_CHECK_GAME                  1017
#define IDC_RADIO_FEMALE                1018
#define IDC_RADIO_MALE                  1019
#define IDC_BNT_OUTPUT                  1020
#define IDC_EDIT_OUTPUT                 1021
#define IDC_COMBO_LIST                  1022
#define IDC_EDIT_NAME                   1023
#define IDC_BTN_INSERT                  1024
#define IDC_BTN_DELETE                  1025
#define IDC_LIST_NAME                   1027
#define IDC_LIST_NAMES                  1027
#define IDC_LIST1                       1029
#define IDC_LIST_CTRL                   1029
#define ID_DrawRectangle                32774
#define ID_DrawCircle                   32775
#define ID_FileOpen                     32776
#define ID_FileSave                     32777
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        136
#define _APS_NEXT_COMMAND_VALUE         32782
#define _APS_NEXT_CONTROL_VALUE         1030
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif

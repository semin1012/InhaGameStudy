#include "framework.h"
#include "cObjectManager.h"


cObjectManager::cObjectManager()
{
}

cObjectManager::~cObjectManager()
{
}
